CloudFormation template to update a Lambda function through CodePipeline via GitHub actions.
